<?php
	$host = "feenix-mariadb.swin.edu.au";
	$user = "s103528518"; // your user name
	$pwd = "swinburne21"; // your password (date of birth ddmmyy unless changed)
	$sql_db = "s103528518_db"; // your database
?>